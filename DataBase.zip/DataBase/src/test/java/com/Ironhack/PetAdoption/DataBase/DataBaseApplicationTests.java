package com.Ironhack.PetAdoption.DataBase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataBaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
