package com.Ironhack.PetAdoption.AnimalSearch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnimalSearchApplicationTests {

	@Test
	void contextLoads() {
	}

}
