package com.Ironhack.PetAdoption.AnimalAdoptionService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnimalAdoptionServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnimalAdoptionServiceApplication.class, args);
	}

}
