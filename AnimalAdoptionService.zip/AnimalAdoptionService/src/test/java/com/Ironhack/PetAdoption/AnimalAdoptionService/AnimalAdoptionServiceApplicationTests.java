package com.Ironhack.PetAdoption.AnimalAdoptionService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnimalAdoptionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
